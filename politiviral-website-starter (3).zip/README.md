# Politiviral

Starter website. Main frontend is in `public/`; campaign data is in `data/campaigns.json`. Render can run it with the included Dockerfile.