# POLITIVIRAL MVP

Deployable version of the supplied POLITIVIRAL MVP prototype.

## Render settings

- Environment: Docker
- Branch: main
- Dockerfile Path: `backend/Dockerfile`
- Docker Build Context Directory: `backend`
- Docker Command: leave empty
- Pre-Deploy Command: leave empty

The current uploaded prototype is a frontend/static MVP served by Nginx. It does not contain a real database, authentication system, or API backend.
