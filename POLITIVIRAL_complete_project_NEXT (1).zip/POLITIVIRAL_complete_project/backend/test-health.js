// Optional smoke test: run `npm start` first, then `node test-health.js`.
// Uses Node 18+ built-in fetch.
fetch('http://localhost:3000/api/health')
  .then(r => r.json())
  .then(x => console.log(x))
  .catch(e => { console.error('Backend is not reachable:', e.message); process.exit(1); });
