const express = require("express");
const fs = require("fs");
const path = require("path");
const crypto = require("crypto");

const app = express();
const PORT = process.env.PORT || 3000;
const DATA_DIR = path.join(__dirname, "data");
const DATA_FILE = path.join(DATA_DIR, "campaigns.json");

fs.mkdirSync(DATA_DIR, { recursive: true });
if (!fs.existsSync(DATA_FILE)) fs.writeFileSync(DATA_FILE, "[]");

app.use(express.json({ limit: "2mb" }));
app.use(express.static(path.join(__dirname, "public")));

function readCampaigns() {
  return JSON.parse(fs.readFileSync(DATA_FILE, "utf8"));
}
function writeCampaigns(items) {
  fs.writeFileSync(DATA_FILE, JSON.stringify(items, null, 2));
}

app.get("/api/health", (_req, res) => {
  res.json({ ok: true, service: "POLITIVIRAL API", time: new Date().toISOString() });
});

app.get("/api/campaigns", (_req, res) => {
  res.json(readCampaigns());
});

app.post("/api/campaigns", (req, res) => {
  const { candidate, position, party, state, title, message, startDate, endDate, budget, language } = req.body || {};
  if (!candidate || !title || !message) {
    return res.status(400).json({ error: "candidate, title and message are required" });
  }

  const campaigns = readCampaigns();
  const item = {
    id: crypto.randomUUID(),
    candidate,
    position: position || "",
    party: party || "",
    state: state || "",
    title,
    message,
    startDate: startDate || null,
    endDate: endDate || null,
    budget: Number(budget || 0),
    language: language || "English",
    status: "pending_review",
    reach: 0,
    createdAt: new Date().toISOString()
  };

  campaigns.push(item);
  writeCampaigns(campaigns);
  res.status(201).json(item);
});

app.get("/api/stats", (_req, res) => {
  const campaigns = readCampaigns();
  const activeCampaigns = campaigns.filter(c => c.status === "active").length;
  const impressions = campaigns.reduce((sum, c) => sum + Number(c.reach || 0), 0);
  res.json({ activeCampaigns, impressions, views: 0, engagement: 0, shares: 0 });
});

app.get("*", (_req, res) => {
  res.sendFile(path.join(__dirname, "public", "index.html"));
});

app.listen(PORT, () => {
  console.log(`POLITIVIRAL running on http://localhost:${PORT}`);
});
