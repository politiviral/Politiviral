# POLITIVIRAL — Complete MVP

This package contains the frontend and backend in one project.

## Structure

- `public/index.html` — POLITIVIRAL dashboard/frontend
- `server.js` — Node.js + Express backend/API
- `data/campaigns.json` — simple persistent campaign storage
- `package.json` — dependencies and start script
- `Dockerfile` — container deployment
- `.env.example` — environment example

## Run locally

1. Install Node.js 20+.
2. Open a terminal in this folder.
3. Run:

```bash
npm install
npm start
```

4. Open `http://localhost:3000`

## API

- `GET /api/health`
- `GET /api/campaigns`
- `POST /api/campaigns`
- `GET /api/stats`

The campaign form is connected to the backend. New campaigns are stored in `data/campaigns.json` and marked `pending_review`.

## GitHub

Upload the contents of this folder to the root of the repository, not the ZIP file itself, if you want GitHub to show the project files directly.

For production, replace the JSON store with a real database, add authentication/authorization, secure file uploads, moderation workflow, audit logging, and platform integrations.
