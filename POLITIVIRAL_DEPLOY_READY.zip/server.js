const express = require("express");
const cors = require("cors");
const multer = require("multer");
const fs = require("fs");
const path = require("path");

const app = express();
const PORT = process.env.PORT || 3000;
const DATA_DIR = path.join(__dirname, "data");
const UPLOAD_DIR = path.join(__dirname, "uploads");
const DB_FILE = path.join(DATA_DIR, "db.json");

fs.mkdirSync(DATA_DIR, {recursive:true});
fs.mkdirSync(UPLOAD_DIR, {recursive:true});

const seed = {
  campaigns: [
    {id:1,title:"A New Dawn for Kano",candidate:"Demo Organization",status:"Active",reach:532760,budget:500000,startDate:"2026-08-01",endDate:"2026-08-31",language:"Hausa + English"},
    {id:2,title:"Youth Empowerment",candidate:"Demo Organization",status:"Completed",reach:312450,budget:300000,startDate:"2026-07-01",endDate:"2026-07-31",language:"English"},
    {id:3,title:"Better Education for All",candidate:"Demo Organization",status:"Draft",reach:0,budget:200000,startDate:"2026-09-10",endDate:"2026-09-30",language:"Hausa"}
  ],
  messages:[
    {from:"POLITIVIRAL Team",message:"Your campaign has been approved.",time:"2m"},
    {from:"Publisher Network",message:"Content scheduled for tomorrow.",time:"1h"},
    {from:"Moderation Team",message:"Waiting for content approval.",time:"2h"}
  ],
  publishers:[
    {name:"Arewa Youth Voice",followers:256000,engagement:8.7,rate:80000},
    {name:"Sani Danja TV",followers:178000,engagement:7.3,rate:60000},
    {name:"Kano Updates",followers:345000,engagement:9.1,rate:100000},
    {name:"Northern Buzz",followers:125000,engagement:6.2,rate:45000}
  ],
  analytics:{impressions:532760,views:385120,engagement:78450,shares:25870}
};
if(!fs.existsSync(DB_FILE)) fs.writeFileSync(DB_FILE, JSON.stringify(seed,null,2));

function readDB(){return JSON.parse(fs.readFileSync(DB_FILE,"utf8"))}
function writeDB(db){fs.writeFileSync(DB_FILE, JSON.stringify(db,null,2))}

const storage = multer.diskStorage({
  destination: (_req,_file,cb)=>cb(null,UPLOAD_DIR),
  filename: (_req,file,cb)=>{
    const safe = file.originalname.replace(/[^a-zA-Z0-9._-]/g,"_");
    cb(null, `${Date.now()}-${safe}`);
  }
});
const upload = multer({
  storage,
  limits:{fileSize:50*1024*1024},
  fileFilter: (_req,file,cb)=>{
    const allowed = /^(image\/|video\/)/i.test(file.mimetype);
    cb(allowed ? null : new Error("Only image or video files are allowed"), allowed);
  }
});

app.use(cors());
app.use(express.json({limit:"1mb"}));
app.use("/uploads", express.static(UPLOAD_DIR));
app.use(express.static(path.join(__dirname,"frontend")));

app.get("/api/health", (_req,res)=>res.json({ok:true,service:"POLITIVIRAL API"}));

app.get("/api/analytics", (_req,res)=>{
  const db=readDB();
  const activeCampaigns=db.campaigns.filter(c=>c.status==="Active").length;
  res.json({...db.analytics,activeCampaigns});
});

app.get("/api/campaigns", (_req,res)=>res.json(readDB().campaigns));

app.get("/api/campaigns/:id", (req,res)=>{
  const campaign=readDB().campaigns.find(c=>String(c.id)===String(req.params.id));
  if(!campaign) return res.status(404).json({error:"Campaign not found"});
  res.json(campaign);
});

app.patch("/api/campaigns/:id/status", (req,res)=>{
  const allowed=["Draft","In Review","Approved","Rejected","Active","Completed"];
  const {status}=req.body||{};
  if(!allowed.includes(status)) return res.status(400).json({error:"Invalid campaign status"});
  const db=readDB();
  const campaign=db.campaigns.find(c=>String(c.id)===String(req.params.id));
  if(!campaign) return res.status(404).json({error:"Campaign not found"});
  campaign.status=status;
  db.messages.unshift({from:"POLITIVIRAL Moderation",message:`${campaign.title} status changed to ${status}.`,time:"now"});
  writeDB(db);
  res.json(campaign);
});

app.post("/api/campaigns", upload.single("media"), (req,res)=>{
  const {candidate,position,party,constituency,title,message,startDate,endDate,budget,language}=req.body;
  if(!candidate || !title || !message || !startDate || !endDate || budget===undefined){
    return res.status(400).json({error:"Required campaign fields are missing"});
  }
  const amount=Number(budget);
  const start=new Date(startDate);
  const end=new Date(endDate);
  if(!Number.isFinite(amount) || amount<0) return res.status(400).json({error:"Budget must be a valid non-negative number"});
  if(Number.isNaN(start.getTime()) || Number.isNaN(end.getTime()) || end<start){
    return res.status(400).json({error:"End date must be on or after start date"});
  }
  const db=readDB();
  const campaign={
    id:Date.now(),
    candidate,position,party,constituency,title,message,startDate,endDate,
    budget:amount,language,status:"In Review",reach:0,
    media:req.file ? `/uploads/${req.file.filename}` : null,
    createdAt:new Date().toISOString()
  };
  db.campaigns.push(campaign);
  db.messages.unshift({from:"POLITIVIRAL Moderation",message:`${title} was submitted for review.`,time:"now"});
  writeDB(db);
  res.status(201).json(campaign);
});

app.get("/api/publishers", (_req,res)=>res.json(readDB().publishers));
app.get("/api/messages", (_req,res)=>res.json(readDB().messages));

app.use((err,_req,res,_next)=>{
  if(err && err.message) return res.status(400).json({error:err.message});
  res.status(500).json({error:"Internal server error"});
});

app.listen(PORT,()=>console.log(`POLITIVIRAL API running on http://localhost:${PORT}`));