# POLITIVIRAL — Complete MVP Project

This package combines the supplied POLITIVIRAL MVP interface with a working Node.js/Express backend.

## Structure

- `frontend/index.html` — dashboard, campaigns, create campaign, publishers, analytics, messages, moderation and profile UI.
- `backend/server.js` — REST API.
- `backend/data/db.json` — local demo data store.
- `backend/uploads/` — uploaded campaign media.
- `backend/Dockerfile` — container configuration.

## Run locally

1. Install Node.js 20+.
2. Open a terminal in the project root.
3. Run:

```bash
npm install
npm start
```

4. Open `http://localhost:3000`.

The frontend is served by the backend, so you do not need a separate frontend server.

## API

- `GET /api/health`
- `GET /api/analytics`
- `GET /api/campaigns`
- `POST /api/campaigns` (multipart form, optional media upload)
- `GET /api/publishers`
- `GET /api/messages`

## GitHub

Upload the contents of this project to the root of your repository. Do not commit real secrets, credentials, payment keys, or private user data.

## Important

This is an MVP/demo backend. Authentication, production database migrations, payment processing, audit logging, rate limiting, secure object storage, moderation workflows, and production deployment hardening still need to be added before real-world use. Political advertising should remain subject to applicable law, disclosure requirements, platform rules, and human moderation.
